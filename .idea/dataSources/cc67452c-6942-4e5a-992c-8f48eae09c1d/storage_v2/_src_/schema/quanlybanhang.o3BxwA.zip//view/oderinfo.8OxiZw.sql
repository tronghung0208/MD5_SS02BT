create definer = root@localhost view oderinfo as
select `c`.`customerName` AS `Tên khách hàng`,
       `c`.`phone`        AS `Số điện thoại`,
       `c`.`address`      AS `Địa chỉ`,
       `o`.`total_amount` AS `Tổng tiền`,
       `o`.`order_date`   AS `Ngày tạo hoá đơn`
from (`quanlybanhang`.`customers` `c` join `quanlybanhang`.`orders` `o` on ((`c`.`customerId` = `o`.`customerId`)));

