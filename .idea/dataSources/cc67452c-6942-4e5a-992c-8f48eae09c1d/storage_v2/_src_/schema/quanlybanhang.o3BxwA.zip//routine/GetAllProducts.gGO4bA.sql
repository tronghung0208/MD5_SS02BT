create
    definer = root@localhost procedure GetAllProducts()
BEGIN
    SELECT *
    FROM products;
END;

