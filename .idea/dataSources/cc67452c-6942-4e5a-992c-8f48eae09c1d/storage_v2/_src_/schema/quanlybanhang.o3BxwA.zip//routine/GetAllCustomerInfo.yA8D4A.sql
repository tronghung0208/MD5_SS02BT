create
    definer = root@localhost procedure GetAllCustomerInfo(IN customer_id varchar(4))
BEGIN
    SELECT *
    FROM customers
    WHERE customerId = customer_id;
END;

