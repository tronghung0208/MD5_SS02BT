create definer = root@localhost view productinfo as
select `p`.`productName`    AS `Tên sản phẩm`,
       `p`.`description`    AS `Mô tả`,
       `p`.`price`          AS `Giá`,
       sum(`od`.`quantity`) AS `Tổng số lượng đã bán ra`
from (`quanlybanhang`.`products` `p` left join `quanlybanhang`.`orders_details` `od`
      on ((`p`.`productId` = `od`.`productId`)))
group by `p`.`productId`, `p`.`productName`, `p`.`description`, `p`.`price`;

