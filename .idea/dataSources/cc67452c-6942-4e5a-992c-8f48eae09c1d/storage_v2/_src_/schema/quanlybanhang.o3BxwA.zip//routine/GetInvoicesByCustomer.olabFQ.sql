create
    definer = root@localhost procedure GetInvoicesByCustomer(IN customer_id varchar(4))
BEGIN
    SELECT o.orderId, o.total_amount, o.order_date
    FROM orders o
    WHERE o.customerId = customer_id;
END;

