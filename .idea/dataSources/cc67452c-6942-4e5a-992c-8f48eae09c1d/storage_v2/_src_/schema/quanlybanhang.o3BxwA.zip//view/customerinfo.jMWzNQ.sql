create definer = root@localhost view customerinfo as
select `c`.`customerName`   AS `Tên khách hàng`,
       `c`.`address`        AS `Địa chỉ`,
       `c`.`phone`          AS `Số điện thoại`,
       count(`o`.`orderId`) AS `Tổng số đơn đã đặt`
from (`quanlybanhang`.`customers` `c` left join `quanlybanhang`.`orders` `o` on ((`c`.`customerId` = `o`.`customerId`)))
group by `c`.`customerName`, `c`.`address`, `c`.`phone`;

