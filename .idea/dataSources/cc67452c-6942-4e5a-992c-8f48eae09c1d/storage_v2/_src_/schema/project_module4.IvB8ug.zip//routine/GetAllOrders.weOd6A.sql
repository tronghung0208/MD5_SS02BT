create
    definer = root@localhost procedure GetAllOrders()
BEGIN
    SELECT * FROM orders;
END;

