create
    definer = root@localhost procedure UpdateUserStatus(IN idParam int)
BEGIN
    UPDATE users
    SET status= CASE WHEN status = 0 THEN 1 ELSE 0 END
    WHERE userId = idParam;
END;

