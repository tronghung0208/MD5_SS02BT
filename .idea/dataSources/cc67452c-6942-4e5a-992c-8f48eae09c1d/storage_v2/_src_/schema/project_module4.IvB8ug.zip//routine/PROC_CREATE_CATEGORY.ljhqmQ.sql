create
    definer = root@localhost procedure PROC_CREATE_CATEGORY(IN categoryName varchar(50))
BEGIN
    INSERT INTO categorys(categoryName) VALUES (categoryName);
END;

