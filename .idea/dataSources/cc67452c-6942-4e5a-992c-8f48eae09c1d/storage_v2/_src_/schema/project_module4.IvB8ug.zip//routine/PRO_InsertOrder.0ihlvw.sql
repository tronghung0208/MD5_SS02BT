create
    definer = root@localhost procedure PRO_InsertOrder(IN p_userId int, IN p_totalAmount double, IN p_name varchar(50),
                                                       IN p_email varchar(50), IN p_phone varchar(50),
                                                       IN p_address varchar(255), IN p_totalPrice double)
BEGIN
    DECLARE currentDateTime DATETIME;
    SET currentDateTime = NOW();

    INSERT INTO orders (userId, orderDate, totalAmount, name, email, phone, address, totalPrice)
    VALUES ( p_userId, currentDateTime, p_totalAmount, p_name, p_email, p_phone, p_address, p_totalPrice );
END;

