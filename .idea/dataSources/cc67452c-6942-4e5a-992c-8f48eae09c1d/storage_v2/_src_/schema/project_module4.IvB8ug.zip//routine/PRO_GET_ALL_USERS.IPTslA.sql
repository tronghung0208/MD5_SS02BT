create
    definer = root@localhost procedure PRO_GET_ALL_USERS()
BEGIN
    SELECT * FROM users WHERE role = 0;
end;

