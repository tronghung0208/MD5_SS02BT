create
    definer = root@localhost procedure PROC_CREATE_PRODUCT(IN pro_productName varchar(50), IN pro_categoryId int,
                                                           IN pro_image varchar(255), IN pro_price double,
                                                           IN pro_description varchar(255), IN pro_stock int)
BEGIN
    INSERT INTO products(productName, categoryId, image, price, description, stock)
    VALUES (pro_productName, pro_categoryId, pro_image, pro_price, pro_description, pro_stock);
END;

