create
    definer = root@localhost procedure PROC_GET_ALL_PRODUCT()
BEGIN
    SELECT p.productId,
           p.productName,
           p.description,
           p.price,
           p.image,
           p.stock,
           p.status,
           p.categoryId
    from products p;
END;

