create
    definer = root@localhost procedure DELETE_CATEGORY(IN categoryIdToDelete int)
BEGIN
    DELETE FROM categorys WHERE categoryId = categoryIdToDelete;
END;

