create
    definer = root@localhost procedure PRO_LOGIN(IN u_email varchar(50))
BEGIN
    SELECT * FROM users WHERE email = u_email;
end;

