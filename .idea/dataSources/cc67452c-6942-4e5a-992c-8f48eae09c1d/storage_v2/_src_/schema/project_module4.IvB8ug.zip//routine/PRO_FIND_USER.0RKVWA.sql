create
    definer = root@localhost procedure PRO_FIND_USER(IN u_userId int)
BEGIN
    SELECT * FROM users WHERE userId = u_userId;
end;

