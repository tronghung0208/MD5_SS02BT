create
    definer = root@localhost procedure PRODUCT_BY_ID(IN idPram int)
BEGIN
    SELECT p.productId,
           p.productName,
           p.categoryId,
           p.image,
           p.price,
           p.description,
           p.stock,
           p.status
    FROM products p
    WHERE p.productId = idPram;
END;

