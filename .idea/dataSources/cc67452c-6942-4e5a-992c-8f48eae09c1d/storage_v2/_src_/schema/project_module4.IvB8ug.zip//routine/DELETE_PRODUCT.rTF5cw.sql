create
    definer = root@localhost procedure DELETE_PRODUCT(IN productIdToDelete int)
BEGIN
    DELETE FROM products WHERE productId = productIdToDelete;
END;

