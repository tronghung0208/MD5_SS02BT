create
    definer = root@localhost procedure UPDATE_PRODUCT(IN newProductName varchar(50), IN newCategoryId int,
                                                      IN newImage varchar(255), IN newPrice double,
                                                      IN newDescription varchar(255), IN newStock int, IN newStatus bit,
                                                      IN newProductId int)
BEGIN
    UPDATE products
    SET productName = newProductName,
        categoryId=newCategoryId,
        image       =newImage,
        price=newPrice,
        description=newDescription,
        stock=newStock,
        status=newStatus,
        productId=newProductId
    WHERE productId = newProductId;
END;

