create
    definer = root@localhost procedure PRO_REGISTER(IN u_userName varchar(50), IN u_email varchar(50),
                                                    IN u_password varchar(255), IN u_address varchar(255),
                                                    IN u_phone varchar(50))
BEGIN
    INSERT INTO users (userName, email, password, address, phone)
    VALUES (u_userName, u_email, u_password, u_address, u_phone);
end;

