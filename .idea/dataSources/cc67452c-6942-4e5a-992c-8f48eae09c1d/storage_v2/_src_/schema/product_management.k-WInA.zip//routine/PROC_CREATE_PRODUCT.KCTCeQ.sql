create
    definer = root@localhost procedure PROC_CREATE_PRODUCT(IN newProductName varchar(50), IN newPrice float,
                                                           IN newImage varchar(200), IN newCategoryId int)
BEGIN
    INSERT INTO products(productName, price,image,categoryId) VALUES (newProductName,newPrice,newImage,newCategoryId);
END;

