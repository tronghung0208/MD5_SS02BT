create
    definer = root@localhost procedure PROC_GET_ALL_PRODUCTS()
BEGIN
    SELECT p.productId, p.productName, p.price,p.image,p.categoryId from products p ;
END;

