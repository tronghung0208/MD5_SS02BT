create
    definer = root@localhost procedure UPDATE_CATEGORY(IN newCategoryId int, IN newCategoryName varchar(50), IN newStatus bit)
BEGIN
    UPDATE categorys SET categoryId = newCategoryId, categoryName = newCategoryName, status = newStatus WHERE categoryId = newCategoryId;
END;

