create
    definer = root@localhost procedure CATEGORY_BY_ID(IN idPram int)
BEGIN
    SELECT c.categoryId, c.categoryName,c.status  FROM categorys c WHERE c.categoryId=idPram;
END;

