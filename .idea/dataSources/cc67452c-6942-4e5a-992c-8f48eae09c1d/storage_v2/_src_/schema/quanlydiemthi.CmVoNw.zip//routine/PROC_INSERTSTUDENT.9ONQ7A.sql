create
    definer = root@localhost procedure PROC_INSERTSTUDENT(IN in_studentId varchar(4), IN in_studentName varchar(100),
                                                          IN in_birthday date, IN in_gender bit, IN in_address text,
                                                          IN in_phoneNumber varchar(45))
BEGIN
    INSERT INTO student(studentId, studentName, birthday, gender, address, phoneNumber)
    VALUES (in_studentId, in_studentName, in_birthday, in_gender, in_address, in_phoneNumber);
END;

