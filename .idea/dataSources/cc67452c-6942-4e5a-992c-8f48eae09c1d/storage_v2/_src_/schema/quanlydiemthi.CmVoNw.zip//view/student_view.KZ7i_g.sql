create definer = root@localhost view student_view as
select `quanlydiemthi`.`student`.`studentId`                                         AS `Mã học sinh`,
       `quanlydiemthi`.`student`.`studentName`                                       AS `Tên học sinh`,
       (case when (`quanlydiemthi`.`student`.`gender` = 1) then 'Nam' else 'Nữ' end) AS `Giới tính`,
       `quanlydiemthi`.`student`.`address`                                           AS `Quê quán`
from `quanlydiemthi`.`student`;

