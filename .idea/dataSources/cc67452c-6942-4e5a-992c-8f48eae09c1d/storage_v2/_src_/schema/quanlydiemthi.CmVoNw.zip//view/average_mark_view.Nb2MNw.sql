create definer = root@localhost view average_mark_view as
select `s`.`studentId`   AS `Mã học sinh`,
       `s`.`studentName` AS `Tên học sinh`,
       avg(`m`.`point`)  AS `Điểm trung bình các môn học`
from (`quanlydiemthi`.`student` `s` left join `quanlydiemthi`.`mark` `m` on ((`s`.`studentId` = `m`.`studentId`)))
group by `s`.`studentId`, `s`.`studentName`;

