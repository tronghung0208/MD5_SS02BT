create
    definer = root@localhost procedure PROC_UPDATESUBJECT(IN in_subjectId varchar(4), IN in_newSubjectName varchar(100))
BEGIN
    UPDATE subject
    SET subjectName = in_newSubjectName
    WHERE subjectId = in_subjectId;
END;

