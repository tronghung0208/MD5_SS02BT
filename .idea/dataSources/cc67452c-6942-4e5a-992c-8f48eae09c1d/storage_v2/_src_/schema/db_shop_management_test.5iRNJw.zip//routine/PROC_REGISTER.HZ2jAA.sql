create
    definer = root@localhost procedure PROC_REGISTER(IN proc_userName varchar(45), IN proc_email varchar(255),
                                                     IN proc_password varchar(255), IN proc_phone varchar(45),
                                                     IN proc_address varchar(255))
BEGIN
    INSERT INTO user(userName, email, password, phone, address) VALUES (proc_userName, proc_email,proc_password,proc_phone,proc_address);
END;

