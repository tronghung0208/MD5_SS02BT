create
    definer = root@localhost procedure PROC_LOGIN(IN proc_email varchar(255))
BEGIN
    SELECT * FROM user WHERE email = proc_email;
END;

