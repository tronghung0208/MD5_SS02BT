create
    definer = root@localhost procedure PROC_GETALLCLASS()
begin
    select s.id, s.name from class s ;
end;

