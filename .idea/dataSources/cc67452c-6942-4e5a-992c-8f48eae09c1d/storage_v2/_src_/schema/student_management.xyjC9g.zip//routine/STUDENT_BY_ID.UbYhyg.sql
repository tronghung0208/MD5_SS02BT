create
    definer = root@localhost procedure STUDENT_BY_ID(IN idPram int)
begin
    select s.id, s.student_name,s.birthday, s.class_id,c.name as className  from student s join class c on c.id = s.class_id where s.id=idPram;
end;

