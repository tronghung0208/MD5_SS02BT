create
    definer = root@localhost procedure PROC_DELETESTUDENTBYID(IN id_ int)
begin
    delete from student where id = id_;
end;

